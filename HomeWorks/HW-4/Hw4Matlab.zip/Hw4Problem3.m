clc; clear; close all;
s = tf('s');
g1 = (5*(s+1)*exp(-2*s)) / (s*(5*s+1));
figure(1)
bode(g1)
g2 = (5*(-s+1))/(s*(5*s+1));
figure(2)
bode(g2)

