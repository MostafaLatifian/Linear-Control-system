clc; clear; close all;
s = tf('s');
g1 = (0.1*(0.1*s+1))/(0.01*s+1)
figure(1)
bode(g1)
figure(2)
nyquist(g1)
