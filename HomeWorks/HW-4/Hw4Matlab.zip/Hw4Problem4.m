clc; clear; close all;
s = tf('s');
g1 = (-(s+1)*(s+2)*(s+3)*(s+4))/((s^3)*(s+100));
%g2=(-0.24*(s+1)*((s/2)+1)*((s/3)+1)*((s/4)+4))/((s^3)*((s/100)+1))
figure(1)
bode(g1)
figure(2)
nyquist(g1)
% figure(3)
% bode(g2)