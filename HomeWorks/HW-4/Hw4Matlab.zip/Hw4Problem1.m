clc; clear; close all;
s = tf('s');
g1 = -1 / (s*(-5*s+1));
figure(1)
bode(g1)
figure(2)
nyquist(g1)
