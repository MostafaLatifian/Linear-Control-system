clc; close all;
s = tf('s');
Ls = 200 / (s*(s+1)*(s+10));
figure(1)
margin(Ls), grid
kp = 0.071;
T=1.79;
kd=kp*T;
Gs=(kp+kd*s) * Ls;
figure(2)
margin(Gs)
Ts= Gs/(1+Gs);
figure(3)
step(Ts)

