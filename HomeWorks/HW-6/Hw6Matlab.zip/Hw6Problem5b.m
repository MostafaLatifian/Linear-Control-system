clc; close all;
s = tf('s');
Ls = 200 / (s*(s+1)*(s+10));
kp = 0.05;
Gs=(kp+0.1*s) * Ls;
figure(1)
margin(Gs)
figure(2)
Gs=(kp+0.3*s) * Ls;
margin(Gs)
figure(3)
Gs=(kp+0.5*s) * Ls;
margin(Gs)

% for kd = 0 : 0.1 : 0.5
%     Gs=(kp+kd*s) * Ls;
%     margin(Gs)
%     hold on
% end
% 
