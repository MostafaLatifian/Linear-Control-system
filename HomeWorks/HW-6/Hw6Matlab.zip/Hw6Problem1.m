clc; close all;
s = tf('s');
Ls = (10) / (s*(s^2+2*s+5)*(s+3));
figure(1)
margin(Ls) , grid
Cs=(30*(28.14*s+1)) /(844.24*s+1);
Ts= Cs*Ls;
figure(2)
margin(Ts) , grid





