clc; close all;
s = tf('s');
Ls = 2500 / (s*(s+25));
figure(1)
margin(Ls)
Cs1 = (1.35*(0.1*s+1)) / (0.142*s+1);
Cs2 = (0.027*s+1) / (1.35*(0.015*s+1));
Gs = Ls*Cs1*Cs2;
figure(2)
margin(Gs)