clc; close all;
s = tf('s');
Ls = (exp(-0.4*s)) / (0.2*s+1);
Cs=(0.045)+(1/s);
figure(1)
margin(Ls*Cs) , grid
Ts= (Cs*Ls) / (1+Cs*Ls);
figure(2)
step(Ts)
stepinfo(Ts)