clc; clear; close all;
s = tf('s');
T = (200.60) / (s^2 + 5.63*s + 126.96)
L = 200.18 / (s^2 + 5.63*s - 73.08 ) 
step(T)
hold on 
step(L)
legend('T', 'L')