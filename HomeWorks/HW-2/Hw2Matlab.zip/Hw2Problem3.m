clc; clear; close all;
s = tf('s');
%% تعریف k های متفاوت برای دستیابی به فراجهش پنج درصد
for k= 8 : 0.2 : 9
    g = k / (s^2 +4*s +k)
    step(g)
    hold on
end
legend('k = 8' , 'k = 8.2' , 'k = 8.4' , 'k = 8.6' , 'k = 8.8' , 'k = 9')
