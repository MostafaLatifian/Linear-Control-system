clc; clear; close all;
s = tf('s');
% تعریف تابع تبدیل سیستم حلقه بسته
T = 0.4 / (s+0.8);
% تعریف تابع تبدیل سیستم حلقه باز
L = 0.4 / (s+0.4);
%% رسم پاسخ پله
step(L,20)
hold on
step(T,20)
legend('T','L')
%% اندازه گیری خطای حالت ماندگار سیستم
Kp = dcgain(L);   
ess = 1 / (1 + Kp)
stepinfo(T);
