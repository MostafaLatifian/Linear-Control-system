clc; clear; close
s = tf('s');
g = 10*(s+2000) / s^2 / (s+5) / (s+2)
rlocus(g)
Ka = dcgain(g * s^2);
ess = 1/Ka
