clc; clear; close
s = tf('s');
g = (s+3)/ s/(s+5) / (s+6) / (s^2+2*s+2)
rlocus(g)
hold on
%rlocus(-g,'--')
%set(findall(figure(1),'type','line'),'linewidth',1.5)