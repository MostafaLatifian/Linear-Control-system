clc; clear; close
s = tf('s');
Gs = (5*s + 10) / (s^2 + 4*s + 5);
Ts = (5*s + 10) / (s^2 + 9*s + 15);
poles = pole(Ts)
poles2 = pole(Gs)
zeros = zero(Ts)
zeros2 = zero(Gs)
damp(Ts)
step(Ts)
stepinfo(Ts)
Ku = dcgain(Gs);
ess = 1/(Ku+1)
