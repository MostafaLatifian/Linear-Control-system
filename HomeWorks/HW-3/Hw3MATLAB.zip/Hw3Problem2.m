clc; clear; close
s = tf('s');
g = (s+1) / (s^3+4*s^2+5*s)
figure(1)
rlocus(g)
% hold on
% rlocus(-g,'--')