clc; clear; close all;
s = tf('s');
g1 = ((2^(1/2))*(s+2))/s^2;
margin(g1),grid